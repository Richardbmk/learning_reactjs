import React from "react";
import useAuth from "../hooks/useAuth";
import { useNavigate, Link } from "react-router-dom";

const Navbar = () => {
  const navigate = useNavigate();
  const { signOut, user } = useAuth();

  const handleLogOut = async (event) => {
    event.preventDefault();
    try {
      navigate("/", { replace: true });
      await signOut();
    } catch (error) {
      console.log(error.message);
    }
  };

  return (
    <nav className="navbar" role="navigation" aria-label="main navigation">
      <div className="navbar-brand">
        <Link className="navbar-item" to="/">
          <img src="hexal-logo.png" width="112" height="28" alt="hexal logo" />
        </Link>
      </div>

      <div id="navbarBasicExample" className="navbar-menu">
        <div className="navbar-start">
          <Link to="/" className="navbar-item">
            Home
          </Link>
          <Link to="/products" className="navbar-item">
            Products
          </Link>
          <Link to="/admin" className="navbar-item">
            Admin
          </Link>
        </div>

        <div className="navbar-end">
          <div className="navbar-item">
            {user !== null && (
              <p>Hello {user?.username}</p>
            )}
            <div className="buttons">
              {user === null ? (
                <div>
                  <Link to="/register" className="button is-primary">
                    <strong>Register</strong>
                  </Link>
                  <Link to="/login" className="button is-light">
                    Log in
                  </Link>
                </div>
              ) : (
                <button onClick={handleLogOut} className="button is-light">
                  Log out
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
