import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
// components
import LoadingSpinner from "./components/LoadingSpinner";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import PrivateLayout from "./components/layouts/PrivateLayout";
// pages
import Home from "./components/Home";
import Products from "./components/Products";
import ProductAdmin from "./components/ProductAdmin";
import LogIn from "./components/auth/LogIn";
import Register from "./components/auth/Register";
import ForgotPassword from "./components/auth/ForgotPassword";
import ForgotPasswordVerification from "./components/auth/ForgotPasswordVerification";
import ChangePassword from "./components/auth/ChangePassword";
import ChangePasswordConfirm from "./components/auth/ChangePasswordConfirm";
import Welcome from "./components/auth/Welcome";
import VerifyEmail from "./components/auth/VerifyEmail";
// other
import useAuth from "./hooks/useAuth";
import "./App.css";

export const App = () => {
  const { userLoading, user } = useAuth();

  return (
    <div className="App">
      <Router>
        <div>
          <Navbar />
          {userLoading ? (
            <LoadingSpinner />
          ) : (
            <Routes>
              <Route
                path="/products"
                element={
                  <PrivateLayout>
                    <Products />
                  </PrivateLayout>
                }
              />
              <Route path="/admin" element={<ProductAdmin />} />
              <Route path="/login" element={<LogIn />} />
              <Route path="/register" element={<Register />} />
              <Route path="/forgotpassword" element={<ForgotPassword />} />
              <Route
                path="/forgotpasswordverification"
                element={<ForgotPasswordVerification />}
              />
              <Route
                path="/changepassword"
                element={
                  <PrivateLayout>
                    <ChangePassword />
                  </PrivateLayout>
                }
              />
              <Route
                path="/changepasswordconfirmation"
                element={<ChangePasswordConfirm />}
              />
              <Route path="/verifyemail" element={<VerifyEmail />} />
              <Route path="/welcome" element={<Welcome />} />
              <Route path="/" element={<Home />} />
            </Routes>
          )}
          <Footer />
        </div>
      </Router>
    </div>
  );
};

export default App;
